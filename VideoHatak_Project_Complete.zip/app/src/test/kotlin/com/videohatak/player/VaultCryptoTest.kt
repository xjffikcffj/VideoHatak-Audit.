package com.videohatak.player

import com.videohatak.player.core.vault.crypto.VaultCryptoManager
import com.videohatak.player.core.vault.db.VaultDatabaseStore
import com.videohatak.player.core.vault.model.VaultVideo
import com.videohatak.player.core.vault.model.toVideoItem
import com.videohatak.player.core.vault.repository.VaultRepositoryImpl
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertThrows
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import org.junit.rules.Timeout
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config
import java.io.ByteArrayInputStream
import java.io.File
import java.io.RandomAccessFile
import java.nio.charset.StandardCharsets
import java.util.Arrays
import javax.crypto.AEADBadTagException

/**
 * Comprehensive Unit Tests for Task 10: Secure Vault Cryptographic Engine.
 *
 * Covers:
 * 1. AES-256 Data Encryption Key (DEK) generation and master key envelope wrapping/unwrapping.
 * 2. Deterministic 12-byte GCM Nonce derivation (salt + chunk index).
 * 3. Strict Nonce uniqueness across chunk sequences.
 * 4. Single-chunk streaming encryption and decryption round-trip.
 * 5. Multi-chunk (boundary-crossing) streaming encryption and decryption round-trip.
 * 6. Random-access Seeking/Scrubbing byte range reading without full file decryption.
 * 7. AEAD Integrity: Tampering detection throws AEADBadTagException.
 * 8. Header Magic and version verification.
 * 9. Handling of 0-byte empty file encryption.
 * 10. Inactivity lock timeout logic.
 * 11. VaultVideo to VideoItem metadata masking (secure_vault bucket, zero leak).
 * 12. Cancellation during encryption: ensures immediate abort and cleanup of temporary files.
 * 13. File header parsing accuracy.
 */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34], manifest = Config.NONE)
class VaultCryptoTest {

    @get:Rule
    val tempFolder = TemporaryFolder()

    @get:Rule
    val timeoutRule: Timeout = Timeout.seconds(30)

    private lateinit var cryptoManager: VaultCryptoManager

    @Before
    fun setUp() {
        // Uses fallback software master key in standard JVM unit test environment
        cryptoManager = VaultCryptoManager(keyStoreProvider = "TEST_PROVIDER")
    }

    @Test
    fun testDekEnvelopeWrappingAndUnwrapping() {
        val dek = cryptoManager.generateDataEncryptionKey()
        assertEquals("AES", dek.algorithm)
        assertEquals(32, dek.encoded.size) // 256 bits

        val wrapped = cryptoManager.wrapDataKey(dek)
        // 12 bytes IV + 32 bytes ciphertext + 16 bytes tag = 60 bytes
        assertEquals(60, wrapped.size)

        val unwrapped = cryptoManager.unwrapDataKey(wrapped)
        assertArrayEquals(dek.encoded, unwrapped.encoded)
    }

    @Test
    fun testNonceDerivationStructure() {
        val fileSalt = byteArrayOf(1, 2, 3, 4, 5, 6, 7, 8)
        val chunkIndex = 0x01020304

        val nonce = cryptoManager.deriveChunkNonce(fileSalt, chunkIndex)
        assertEquals(12, nonce.size)

        // First 8 bytes must match fileSalt exactly
        for (i in 0 until 8) {
            assertEquals(fileSalt[i], nonce[i])
        }

        // Last 4 bytes must match big-endian chunkIndex
        assertEquals(0x01.toByte(), nonce[8])
        assertEquals(0x02.toByte(), nonce[9])
        assertEquals(0x03.toByte(), nonce[10])
        assertEquals(0x04.toByte(), nonce[11])
    }

    @Test
    fun testNonceUniquenessAcrossChunks() {
        val fileSalt = byteArrayOf(10, 20, 30, 40, 50, 60, 70, 80)
        val generatedNonces = HashSet<String>()

        for (i in 0..1000) {
            val nonce = cryptoManager.deriveChunkNonce(fileSalt, i)
            val hex = nonce.joinToString("") { "%02x".format(it) }
            val added = generatedNonces.add(hex)
            assertTrue("Nonce for chunk $i must be globally unique within file", added)
        }
    }

    @Test
    fun testSingleChunkEncryptionAndDecryption() {
        val plainText = "VideoHatak Secure Vault - تشفير محلي عالي الأمان بنظام AES-256-GCM"
        val plainBytes = plainText.toByteArray(StandardCharsets.UTF_8)
        val destFile = tempFolder.newFile("test_single.enc")

        val result = cryptoManager.encryptStream(
            inputStream = ByteArrayInputStream(plainBytes),
            destinationFile = destFile,
            totalBytesEstimated = plainBytes.size.toLong(),
            chunkSize = 64 * 1024
        )

        assertEquals(plainBytes.size.toLong(), result.plaintextSizeBytes)
        assertTrue(destFile.exists())
        assertTrue(destFile.length() > plainBytes.size) // header + ciphertext + GCM tag

        // Read decrypted range
        val outBuffer = ByteArray(plainBytes.size)
        val readBytes = cryptoManager.readDecryptedRange(
            encryptedFile = destFile,
            fileSalt = result.fileSalt,
            wrappedDek = result.encryptedDek,
            chunkSize = result.chunkSize,
            plaintextSize = result.plaintextSizeBytes,
            headerSize = result.headerSize,
            requestedOffset = 0L,
            outBuffer = outBuffer,
            outBufferOffset = 0,
            requestedLength = plainBytes.size
        )

        assertEquals(plainBytes.size, readBytes)
        assertArrayEquals(plainBytes, outBuffer)
    }

    @Test
    fun testMultiChunkEncryptionAndCrossChunkSeeking() {
        // Create 150 KB of deterministic test payload (> 2 chunks of 64 KB)
        val chunkSize = 64 * 1024
        val totalSize = 150 * 1024
        val testPayload = ByteArray(totalSize)
        for (i in 0 until totalSize) {
            testPayload[i] = (i % 251).toByte()
        }

        val destFile = tempFolder.newFile("test_multi.enc")
        val result = cryptoManager.encryptStream(
            inputStream = ByteArrayInputStream(testPayload),
            destinationFile = destFile,
            totalBytesEstimated = totalSize.toLong(),
            chunkSize = chunkSize
        )

        assertEquals(totalSize.toLong(), result.plaintextSizeBytes)

        // Read range crossing chunk 0, chunk 1, and chunk 2 (e.g. from 60 KB to 140 KB = 80 KB)
        val seekOffset = 60 * 1024L
        val readLength = 80 * 1024
        val outBuffer = ByteArray(readLength)

        val readBytes = cryptoManager.readDecryptedRange(
            encryptedFile = destFile,
            fileSalt = result.fileSalt,
            wrappedDek = result.encryptedDek,
            chunkSize = result.chunkSize,
            plaintextSize = result.plaintextSizeBytes,
            headerSize = result.headerSize,
            requestedOffset = seekOffset,
            outBuffer = outBuffer,
            outBufferOffset = 0,
            requestedLength = readLength
        )

        assertEquals(readLength, readBytes)

        val expectedSlice = Arrays.copyOfRange(testPayload, seekOffset.toInt(), (seekOffset + readLength).toInt())
        assertArrayEquals(expectedSlice, outBuffer)
    }

    @Test
    fun testRandomAccessSeekingAtArbitraryOffset() {
        val testPayload = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz".repeat(2000).toByteArray()
        val destFile = tempFolder.newFile("test_seek.enc")
        val chunkSize = 1024 // 1 KB chunks for multi-chunk boundaries

        val result = cryptoManager.encryptStream(
            inputStream = ByteArrayInputStream(testPayload),
            destinationFile = destFile,
            totalBytesEstimated = testPayload.size.toLong(),
            chunkSize = chunkSize
        )

        // Arbitrary seek offset: 2555, read 50 bytes
        val offset = 2555L
        val length = 50
        val outBuffer = ByteArray(length)

        val read = cryptoManager.readDecryptedRange(
            encryptedFile = destFile,
            fileSalt = result.fileSalt,
            wrappedDek = result.encryptedDek,
            chunkSize = result.chunkSize,
            plaintextSize = result.plaintextSizeBytes,
            headerSize = result.headerSize,
            requestedOffset = offset,
            outBuffer = outBuffer,
            outBufferOffset = 0,
            requestedLength = length
        )

        assertEquals(length, read)
        val expected = Arrays.copyOfRange(testPayload, offset.toInt(), (offset + length).toInt())
        assertArrayEquals(expected, outBuffer)
    }

    @Test
    fun testTamperingThrowsAEADBadTagException() {
        val payload = "Confidential Vault Data 12345".toByteArray()
        val destFile = tempFolder.newFile("tampered.enc")

        val result = cryptoManager.encryptStream(
            inputStream = ByteArrayInputStream(payload),
            destinationFile = destFile,
            totalBytesEstimated = payload.size.toLong(),
            chunkSize = 64 * 1024
        )

        // Corrupt one single byte in the ciphertext chunk
        val raf = RandomAccessFile(destFile, "rw")
        raf.seek(result.headerSize.toLong() + 5L)
        val b = raf.readByte()
        raf.seek(result.headerSize.toLong() + 5L)
        raf.writeByte((b.toInt() xor 0xFF))
        raf.close()

        val outBuffer = ByteArray(payload.size)

        assertThrows(AEADBadTagException::class.java) {
            cryptoManager.readDecryptedRange(
                encryptedFile = destFile,
                fileSalt = result.fileSalt,
                wrappedDek = result.encryptedDek,
                chunkSize = result.chunkSize,
                plaintextSize = result.plaintextSizeBytes,
                headerSize = result.headerSize,
                requestedOffset = 0L,
                outBuffer = outBuffer,
                outBufferOffset = 0,
                requestedLength = payload.size
            )
        }
    }

    @Test
    fun testHeaderParsingAndMagicValidation() {
        val payload = "Header Test Data".toByteArray()
        val destFile = tempFolder.newFile("header_test.enc")

        val result = cryptoManager.encryptStream(
            inputStream = ByteArrayInputStream(payload),
            destinationFile = destFile,
            totalBytesEstimated = payload.size.toLong()
        )

        val header = cryptoManager.parseEncryptedFileHeader(destFile)
        assertArrayEquals(result.fileSalt, header.fileSalt)
        assertArrayEquals(result.encryptedDek, header.encryptedDek)
        assertEquals(payload.size.toLong(), header.plaintextSizeBytes)
        assertEquals(VaultCryptoManager.DEFAULT_CHUNK_SIZE, header.chunkSize)
        assertEquals(result.headerSize, header.headerSize)
    }

    @Test
    fun testCorruptHeaderMagicRejection() {
        val destFile = tempFolder.newFile("corrupt_magic.enc")
        val raf = RandomAccessFile(destFile, "rw")
        raf.write("BADMAGIC".toByteArray())
        raf.close()

        assertThrows(IllegalArgumentException::class.java) {
            cryptoManager.parseEncryptedFileHeader(destFile)
        }
    }

    @Test
    fun testZeroByteFileHandling() {
        val destFile = tempFolder.newFile("empty.enc")
        val result = cryptoManager.encryptStream(
            inputStream = ByteArrayInputStream(ByteArray(0)),
            destinationFile = destFile,
            totalBytesEstimated = 0L
        )

        assertEquals(0L, result.plaintextSizeBytes)

        val outBuffer = ByteArray(10)
        val read = cryptoManager.readDecryptedRange(
            encryptedFile = destFile,
            fileSalt = result.fileSalt,
            wrappedDek = result.encryptedDek,
            chunkSize = result.chunkSize,
            plaintextSize = 0L,
            headerSize = result.headerSize,
            requestedOffset = 0L,
            outBuffer = outBuffer,
            outBufferOffset = 0,
            requestedLength = 10
        )
        assertEquals(-1, read) // EOF
    }

    @Test
    fun testInactivityTimeoutLogic() {
        val timeoutMs = 3 * 60 * 1000L // 3 minutes
        val now = 1_000_000L

        // Active 1 minute ago -> Not timed out
        val recentInteraction = now - (60 * 1000L)
        val isTimedOutRecent = (now - recentInteraction) > timeoutMs
        assertFalse(isTimedOutRecent)

        // Active 4 minutes ago -> Timed out
        val oldInteraction = now - (4 * 60 * 1000L)
        val isTimedOutOld = (now - oldInteraction) > timeoutMs
        assertTrue(isTimedOutOld)
    }

    @Test
    fun testVaultVideoToVideoItemMasking() {
        val vaultVideo = VaultVideo(
            id = 42L,
            displayName = "وثائقي_سري.mp4",
            originalSizeBytes = 50_000_000L,
            encryptedSizeBytes = 50_020_000L,
            durationMs = 120_000L,
            mimeType = "video/mp4",
            width = 1920,
            height = 1080,
            relativeEncryptedPath = "videos/vault_42.enc",
            createdAtEpochMs = 1700000000000L
        )

        val item = vaultVideo.toVideoItem()
        assertEquals(42L, item.id)
        assertEquals("vault://42", item.uri)
        assertEquals("وثائقي_سري.mp4", item.title)
        assertEquals("secure_vault", item.bucketId)
        assertEquals("الخزنة الخاصة", item.bucketName)
        assertEquals(120_000L, item.durationMs)
        assertEquals(1920, item.width)
        assertEquals(1080, item.height)
    }

    @Test
    fun testPartialStreamReadingAccumulatesFullChunks() {
        val totalSize = 130 * 1024 // 2 full chunks (64KB each) + 2KB final chunk
        val payload = ByteArray(totalSize) { (it % 253).toByte() }

        // InputStream that yields at most 512 bytes per read
        val irregularStream = object : java.io.InputStream() {
            private var index = 0
            override fun read(): Int {
                return if (index < totalSize) payload[index++].toInt() and 0xFF else -1
            }
            override fun read(b: ByteArray, off: Int, len: Int): Int {
                if (index >= totalSize) return -1
                val chunk = minOf(len, 512, totalSize - index)
                System.arraycopy(payload, index, b, off, chunk)
                index += chunk
                return chunk
            }
        }

        val destFile = tempFolder.newFile("test_irregular_stream.enc")
        val result = cryptoManager.encryptStream(
            inputStream = irregularStream,
            destinationFile = destFile,
            totalBytesEstimated = totalSize.toLong(),
            chunkSize = 64 * 1024
        )

        assertEquals(totalSize.toLong(), result.plaintextSizeBytes)

        // Verify seek read across chunk boundary (from 60KB to 70KB)
        val readBuffer = ByteArray(10 * 1024)
        val readCount = cryptoManager.readDecryptedRange(
            encryptedFile = destFile,
            fileSalt = result.fileSalt,
            wrappedDek = result.encryptedDek,
            chunkSize = result.chunkSize,
            plaintextSize = result.plaintextSizeBytes,
            headerSize = result.headerSize,
            requestedOffset = 60 * 1024L,
            outBuffer = readBuffer,
            outBufferOffset = 0,
            requestedLength = readBuffer.size
        )

        assertEquals(readBuffer.size, readCount)
        val expected = Arrays.copyOfRange(payload, 60 * 1024, 70 * 1024)
        assertArrayEquals(expected, readBuffer)
    }

    @Test
    fun testHeaderTamperingDetectionFileSalt() {
        val payload = "Important Vault Video Stream Data".toByteArray()
        val destFile = tempFolder.newFile("tampered_salt.enc")

        val result = cryptoManager.encryptStream(
            inputStream = ByteArrayInputStream(payload),
            destinationFile = destFile,
            totalBytesEstimated = payload.size.toLong(),
            chunkSize = 64 * 1024
        )

        // Alter fileSalt in header (at offset 8: MAGIC is 8 bytes, salt is 8 bytes)
        val raf = RandomAccessFile(destFile, "rw")
        raf.seek(9L)
        val b = raf.readByte()
        raf.seek(9L)
        raf.writeByte(b.toInt() xor 0xAA)
        raf.close()

        val header = cryptoManager.parseEncryptedFileHeader(destFile)
        val outBuffer = ByteArray(payload.size)

        assertThrows(AEADBadTagException::class.java) {
            cryptoManager.readDecryptedRange(
                encryptedFile = destFile,
                fileSalt = header.fileSalt,
                wrappedDek = header.encryptedDek,
                chunkSize = header.chunkSize,
                plaintextSize = header.plaintextSizeBytes,
                headerSize = header.headerSize,
                requestedOffset = 0L,
                outBuffer = outBuffer,
                outBufferOffset = 0,
                requestedLength = payload.size
            )
        }
    }

    @Test
    fun testHeaderTamperingDetectionPlaintextSize() {
        val payload = "Important Vault Video Stream Data".toByteArray()
        val destFile = tempFolder.newFile("tampered_size.enc")

        val result = cryptoManager.encryptStream(
            inputStream = ByteArrayInputStream(payload),
            destinationFile = destFile,
            totalBytesEstimated = payload.size.toLong(),
            chunkSize = 64 * 1024
        )

        // Alter plaintextSize in header (last 8 bytes of header)
        val raf = RandomAccessFile(destFile, "rw")
        raf.seek(result.headerSize.toLong() - 4L)
        val b = raf.readByte()
        raf.seek(result.headerSize.toLong() - 4L)
        raf.writeByte(b.toInt() xor 0xFF)
        raf.close()

        val header = cryptoManager.parseEncryptedFileHeader(destFile)
        val outBuffer = ByteArray(payload.size)

        assertThrows(AEADBadTagException::class.java) {
            cryptoManager.readDecryptedRange(
                encryptedFile = destFile,
                fileSalt = header.fileSalt,
                wrappedDek = header.encryptedDek,
                chunkSize = header.chunkSize,
                plaintextSize = header.plaintextSizeBytes,
                headerSize = header.headerSize,
                requestedOffset = 0L,
                outBuffer = outBuffer,
                outBufferOffset = 0,
                requestedLength = payload.size
            )
        }
    }

    @Test
    fun testMemoryZeroingHygiene() {
        val sensitiveBuffer = byteArrayOf(0x01, 0x02, 0x03, 0x04, 0x05)
        cryptoManager.zeroByteArray(sensitiveBuffer)
        for (b in sensitiveBuffer) {
            assertEquals(0.toByte(), b)
        }
    }

    @Test
    fun testBackwardCompatibilityUnwrapWithoutAad() {
        val dek = cryptoManager.generateDataEncryptionKey()
        // Wrap without AAD (legacy style)
        val wrappedLegacy = cryptoManager.wrapDataKey(dek, aad = null)

        // Unwrap with fallback should succeed even if AAD was not supplied
        val unwrapped = cryptoManager.unwrapDataKeyWithFallback(wrappedLegacy, aad = null)
        assertArrayEquals(dek.encoded, unwrapped.encoded)
    }

    @Test
    fun testPartialStreamReadingWithIntermittentZeroReads() {
        val totalSize = 140 * 1024 // > 2 chunks
        val payload = ByteArray(totalSize) { (it % 251).toByte() }

        // Stream that returns 0 bytes alternately with small chunks (e.g. 1024 bytes)
        val intermittentStream = object : java.io.InputStream() {
            private var index = 0
            private var shouldReturnZero = false

            override fun read(): Int {
                return if (index < totalSize) payload[index++].toInt() and 0xFF else -1
            }

            override fun read(b: ByteArray, off: Int, len: Int): Int {
                if (index >= totalSize) return -1
                if (shouldReturnZero) {
                    shouldReturnZero = false
                    return 0 // Intermittent 0-byte non-blocking read simulation
                }
                shouldReturnZero = true
                val toRead = minOf(len, 1024, totalSize - index)
                System.arraycopy(payload, index, b, off, toRead)
                index += toRead
                return toRead
            }
        }

        val destFile = tempFolder.newFile("test_zero_reads.enc")
        val result = cryptoManager.encryptStream(
            inputStream = intermittentStream,
            destinationFile = destFile,
            totalBytesEstimated = totalSize.toLong(),
            chunkSize = 64 * 1024
        )

        assertEquals(totalSize.toLong(), result.plaintextSizeBytes)

        // Verify seeking and reading arbitrary slice
        val out = ByteArray(5000)
        val count = cryptoManager.readDecryptedRange(
            encryptedFile = destFile,
            fileSalt = result.fileSalt,
            wrappedDek = result.encryptedDek,
            chunkSize = result.chunkSize,
            plaintextSize = result.plaintextSizeBytes,
            headerSize = result.headerSize,
            requestedOffset = 70_000L,
            outBuffer = out,
            outBufferOffset = 0,
            requestedLength = 5000
        )

        assertEquals(5000, count)
        val expected = Arrays.copyOfRange(payload, 70_000, 75_000)
        assertArrayEquals(expected, out)
    }

    @Test
    fun testHeaderTamperingDetectionChunkSize() {
        val payload = "Confidential Video Content 12345".toByteArray()
        val destFile = tempFolder.newFile("tampered_chunk_size.enc")

        val result = cryptoManager.encryptStream(
            inputStream = ByteArrayInputStream(payload),
            destinationFile = destFile,
            totalBytesEstimated = payload.size.toLong(),
            chunkSize = 64 * 1024
        )

        // Alter chunkSize in header:
        // Header structure: Magic(8) + Salt(8) + DekLen(4) + WrappedDek(60) + ChunkSize(4)
        // Offset of chunkSize = 8 + 8 + 4 + 60 = 80
        val raf = RandomAccessFile(destFile, "rw")
        raf.seek(80L)
        val originalChunkSize = raf.readInt()
        raf.seek(80L)
        raf.writeInt(originalChunkSize + 1024)
        raf.close()

        val header = cryptoManager.parseEncryptedFileHeader(destFile)
        val outBuffer = ByteArray(payload.size)

        assertThrows(AEADBadTagException::class.java) {
            cryptoManager.readDecryptedRange(
                encryptedFile = destFile,
                fileSalt = header.fileSalt,
                wrappedDek = header.encryptedDek,
                chunkSize = header.chunkSize,
                plaintextSize = header.plaintextSizeBytes,
                headerSize = header.headerSize,
                requestedOffset = 0L,
                outBuffer = outBuffer,
                outBufferOffset = 0,
                requestedLength = payload.size
            )
        }
    }

    @Test
    fun testChunkTamperingOrderSwappingThrowsAEADBadTagException() {
        // Multi-chunk file: 2 full chunks
        val chunkSize = 1024 // 1KB chunks for fast swapping test
        val totalSize = 2048
        val payload = ByteArray(totalSize) { (it % 100).toByte() }
        val destFile = tempFolder.newFile("swapped_chunks.enc")

        val result = cryptoManager.encryptStream(
            inputStream = ByteArrayInputStream(payload),
            destinationFile = destFile,
            totalBytesEstimated = totalSize.toLong(),
            chunkSize = chunkSize
        )

        // Read chunk 0 and chunk 1 from file
        val raf = RandomAccessFile(destFile, "rw")
        raf.seek(result.headerSize.toLong())
        val size0 = raf.readInt()
        val enc0 = ByteArray(size0)
        raf.readFully(enc0)

        val size1 = raf.readInt()
        val enc1 = ByteArray(size1)
        raf.readFully(enc1)

        // Swap: write chunk 1 at chunk 0's place, and chunk 0 at chunk 1's place
        raf.seek(result.headerSize.toLong())
        raf.writeInt(size1)
        raf.write(enc1)
        raf.writeInt(size0)
        raf.write(enc0)
        raf.close()

        val outBuffer = ByteArray(chunkSize)

        // Attempting to read chunk 0 (which now contains chunk 1's data with chunk 0's expected nonce and AAD)
        assertThrows(AEADBadTagException::class.java) {
            cryptoManager.readDecryptedRange(
                encryptedFile = destFile,
                fileSalt = result.fileSalt,
                wrappedDek = result.encryptedDek,
                chunkSize = result.chunkSize,
                plaintextSize = result.plaintextSizeBytes,
                headerSize = result.headerSize,
                requestedOffset = 0L,
                outBuffer = outBuffer,
                outBufferOffset = 0,
                requestedLength = chunkSize
            )
        }
    }

    @Test
    fun testRandomAccessSeekingForwardAndBackward() {
        val chunkSize = 64 * 1024
        val totalSize = 180 * 1024 // 2 full chunks (64KB each) + 52KB partial final chunk
        val payload = ByteArray(totalSize) { (it % 251).toByte() }
        val destFile = tempFolder.newFile("test_bidirectional_seek.enc")

        val result = cryptoManager.encryptStream(
            inputStream = ByteArrayInputStream(payload),
            destinationFile = destFile,
            totalBytesEstimated = totalSize.toLong(),
            chunkSize = chunkSize
        )

        val buffer = ByteArray(1000)

        // Seek forward to chunk 2 (final partial chunk at offset 150,000)
        val read1 = cryptoManager.readDecryptedRange(
            encryptedFile = destFile,
            fileSalt = result.fileSalt,
            wrappedDek = result.encryptedDek,
            chunkSize = result.chunkSize,
            plaintextSize = result.plaintextSizeBytes,
            headerSize = result.headerSize,
            requestedOffset = 150_000L,
            outBuffer = buffer,
            outBufferOffset = 0,
            requestedLength = 1000
        )
        assertEquals(1000, read1)
        assertArrayEquals(Arrays.copyOfRange(payload, 150_000, 151_000), buffer)

        // Seek backward to chunk 0 (offset 500)
        val read2 = cryptoManager.readDecryptedRange(
            encryptedFile = destFile,
            fileSalt = result.fileSalt,
            wrappedDek = result.encryptedDek,
            chunkSize = result.chunkSize,
            plaintextSize = result.plaintextSizeBytes,
            headerSize = result.headerSize,
            requestedOffset = 500L,
            outBuffer = buffer,
            outBufferOffset = 0,
            requestedLength = 1000
        )
        assertEquals(1000, read2)
        assertArrayEquals(Arrays.copyOfRange(payload, 500, 1500), buffer)

        // Seek forward to chunk 1 (offset 70,000)
        val read3 = cryptoManager.readDecryptedRange(
            encryptedFile = destFile,
            fileSalt = result.fileSalt,
            wrappedDek = result.encryptedDek,
            chunkSize = result.chunkSize,
            plaintextSize = result.plaintextSizeBytes,
            headerSize = result.headerSize,
            requestedOffset = 70_000L,
            outBuffer = buffer,
            outBufferOffset = 0,
            requestedLength = 1000
        )
        assertEquals(1000, read3)
        assertArrayEquals(Arrays.copyOfRange(payload, 70_000, 71_000), buffer)
    }

    @Test
    fun testFileSmallerThanSingleChunk() {
        val totalSize = 15 * 1024 // 15 KB < 64 KB chunk size
        val payload = ByteArray(totalSize) { (it % 127).toByte() }
        val destFile = tempFolder.newFile("test_small_file.enc")

        val result = cryptoManager.encryptStream(
            inputStream = ByteArrayInputStream(payload),
            destinationFile = destFile,
            totalBytesEstimated = totalSize.toLong(),
            chunkSize = 64 * 1024
        )

        assertEquals(totalSize.toLong(), result.plaintextSizeBytes)

        val out = ByteArray(totalSize)
        val count = cryptoManager.readDecryptedRange(
            encryptedFile = destFile,
            fileSalt = result.fileSalt,
            wrappedDek = result.encryptedDek,
            chunkSize = result.chunkSize,
            plaintextSize = result.plaintextSizeBytes,
            headerSize = result.headerSize,
            requestedOffset = 0L,
            outBuffer = out,
            outBufferOffset = 0,
            requestedLength = totalSize
        )

        assertEquals(totalSize, count)
        assertArrayEquals(payload, out)
    }

    @Test
    fun testPersistentZeroReadsThrowsIOExceptionAndCleansUpTempFile() {
        val destFile = File(tempFolder.root, "stalled_stream.enc")
        val tempFile = File(destFile.parentFile, "${destFile.name}.tmp")
        assertFalse(destFile.exists())

        // Stream that delivers 10KB then stalls completely, returning 0 repeatedly
        val stalledStream = object : java.io.InputStream() {
            private var bytesDelivered = 0
            override fun read(): Int {
                return if (bytesDelivered < 10 * 1024) {
                    bytesDelivered++
                    0x55
                } else {
                    0 // Persistent zero read
                }
            }

            override fun read(b: ByteArray, off: Int, len: Int): Int {
                if (bytesDelivered < 10 * 1024) {
                    val toDeliver = minOf(len, 10 * 1024 - bytesDelivered)
                    Arrays.fill(b, off, off + toDeliver, 0x55.toByte())
                    bytesDelivered += toDeliver
                    return toDeliver
                }
                return 0 // Persistent 0-byte read simulation
            }
        }

        val exception = assertThrows(java.io.IOException::class.java) {
            cryptoManager.encryptStream(
                inputStream = stalledStream,
                destinationFile = destFile,
                totalBytesEstimated = 100 * 1024L,
                chunkSize = 64 * 1024
            )
        }

        assertTrue(exception.message?.contains("Stream stalled") == true)
        // Ensure no corrupt or incomplete temporary file remains on disk
        assertFalse("Incomplete temp file must be deleted upon IOException", tempFile.exists())
        assertFalse("Destination file must not be created on stream stall", destFile.exists())
    }

    @Test
    fun testCancellationCleansUpTempFile() {
        val destFile = tempFolder.newFile("cancel_test.enc")
        val tempFile = File(destFile.parentFile, "${destFile.name}.tmp")
        val stream = ByteArrayInputStream(ByteArray(500 * 1024))

        var cancelled = false

        assertThrows(InterruptedException::class.java) {
            cryptoManager.encryptStream(
                inputStream = stream,
                destinationFile = destFile,
                totalBytesEstimated = 500 * 1024L,
                chunkSize = 64 * 1024,
                onProgress = { progress ->
                    if (progress > 0.05f) {
                        cancelled = true
                    }
                },
                isCancelled = { cancelled }
            )
        }

        // Temp file must be purged cleanly upon cancellation
        assertFalse(tempFile.exists())
    }

    @Test
    fun testTwoPhaseVaultDeletionRestoresFileOnDbFailureAndDeletesOnCommit() = runBlocking {
        val appContext = RuntimeEnvironment.getApplication()
        val vaultDir = File(appContext.filesDir, "vault_encrypted").apply { mkdirs() }
        val encryptedFile = File(vaultDir, "two_phase_test.enc")
        val cipherBytes = "ENCRYPTED_PAYLOAD_BYTES".toByteArray()
        encryptedFile.writeBytes(cipherBytes)

        val encryptedMeta = cryptoManager.encryptMetadata(
            """{"title":"Secret Video","file":"two_phase_test.enc","mime":"video/mp4"}"""
        )
        val storedRow = VaultVideo(
            id = 77L,
            displayName = "مقطع خاص مشفر",
            originalSizeBytes = cipherBytes.size.toLong(),
            encryptedSizeBytes = cipherBytes.size.toLong(),
            durationMs = 5_000L,
            mimeType = "application/octet-stream",
            width = 1280,
            height = 720,
            relativeEncryptedPath = "two_phase_test.enc",
            createdAtEpochMs = 1_700_000_000L,
            ivBase64 = "AA==",
            encryptedMetaBase64 = encryptedMeta
        )

        var failDbDelete = true
        val fakeDb = object : VaultDatabaseStore {
            private var rowPresent = true
            override fun insertVideo(video: VaultVideo): Long = storedRow.id
            override fun updateEncryptedMetadata(
                id: Long,
                maskedDisplayName: String,
                internalPath: String,
                maskedMimeType: String,
                encryptedMetaBase64: String
            ): Int = 1
            override fun getAllVideos(): List<VaultVideo> = if (rowPresent) listOf(storedRow) else emptyList()
            override fun getVideoById(id: Long): VaultVideo? = if (rowPresent && id == storedRow.id) storedRow else null
            override fun deleteVideo(id: Long): Int {
                if (failDbDelete) return 0
                rowPresent = false
                return 1
            }
        }

        val repo = VaultRepositoryImpl(
            context = appContext,
            cryptoManager = cryptoManager,
            dbHelper = fakeDb
        )
        repo.setUnlocked(true)

        // Phase 1 failure: DB delete returns 0 -> encrypted file must be rolled back intact
        val failedDelete = repo.deleteVaultVideo(storedRow.id)
        assertFalse(failedDelete)
        assertTrue("Encrypted vault file must be restored when DB delete fails", encryptedFile.exists())
        assertArrayEquals(cipherBytes, encryptedFile.readBytes())
        assertFalse(vaultDir.listFiles().orEmpty().any { it.name.endsWith(".pending_delete") })

        // Phase 2 success: DB delete commits -> encrypted file & staging file removed cleanly
        failDbDelete = false
        val succeededDelete = repo.deleteVaultVideo(storedRow.id)
        assertTrue(succeededDelete)
        assertFalse("Encrypted vault file must be removed after committed DB delete", encryptedFile.exists())
        assertFalse(vaultDir.listFiles().orEmpty().any { it.name.endsWith(".pending_delete") })
    }
}
